rm -rf rapidjson
git clone https://github.com/miloyip/rapidjson
