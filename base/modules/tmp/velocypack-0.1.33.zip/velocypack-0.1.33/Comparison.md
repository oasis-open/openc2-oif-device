Comparison of VelocyPack to other formats
=========================================

  - MessagePack
  - Protocol Buffers
  - Thrift
  - Google's flat buffers
  - JSON
  - BSON

Pro/Contra for each
Use cases

Performance and size overview

Table
