Sample JSON files
=================

The `fail*.json` and `pass*.json` files in this directory are from the 
[JSON checker](http://json.org/JSON_checker/) [test suite](http://json.org/JSON_checker/test.zip).
The file `sample.json` was downloaded from the [json-test-suite project](http://code.google.com/p/json-test-suite/downloads/detail?name=sample.zip).
