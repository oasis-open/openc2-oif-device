Using VPack
===========

This directory contains example code that demonstrates the usage of the
VPack library from C++ programs. Please consult the file [API.md](API.md) for 
a description of the main VPack classes and explained usage examples.

The file [Embedding.md](Embedding.md) contains additional information
about how to embed the VPack library into client applications.
