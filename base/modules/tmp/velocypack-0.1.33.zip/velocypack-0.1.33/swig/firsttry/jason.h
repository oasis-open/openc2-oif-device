#include <string>

char* JsonToJason (std::string s);
unsigned long int ByteLength(char* p);
