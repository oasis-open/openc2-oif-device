Please note that for legal reasons we require you to sign the 
[Contributor Agreement](https://www.arangodb.com/documents/cla.pdf)
before we can accept your pull requests.

Code changes and contributions in the VelocyPack library should use 
the "Google" style and conventions as used by *clang-format*. 
